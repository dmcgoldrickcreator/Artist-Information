export default function Info() {
  return "Info goes here";
}
