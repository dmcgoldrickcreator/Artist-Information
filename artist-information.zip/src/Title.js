export default function Title() {
  return <h1>Artist Information</h1>;
}
